package com.doramastudio.mobile

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Scene(val number: Int, val start: String, val end: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DoramaStudioApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DoramaStudioApp() {
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Выберите серию") }
    var scenes by remember { mutableStateOf(emptyList<Scene>()) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        videoUri = uri
        if (uri != null) {
            status = "Видео выбрано. Можно перейти к монтажу."
            scenes = List(10) { i ->
                val start = i * 5
                Scene(
                    i + 1,
                    "%02d:%02d".format(start / 60, start % 60),
                    "%02d:%02d".format((start + 5) / 60, (start + 5) % 60)
                )
            }
        }
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Dorama Studio Mobile") }) }) { padding ->
            LazyColumn(
                modifier = Modifier.padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Автоматическая нарезка дорам", style = MaterialTheme.typography.headlineSmall)
                    Text("Импорт видео, план сцен и подготовка к автоматическому монтажу.")
                }
                item {
                    Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                        Text("ВЫБРАТЬ ВИДЕО")
                    }
                }
                item {
                    Text(status)
                    if (videoUri != null) {
                        Text("Файл: ${videoUri!!.lastPathSegment ?: "выбран"}")
                    }
                }
                item {
                    Button(
                        onClick = { status = "План сцен готов. Реальный FFmpeg-монтаж подключим следующим этапом." },
                        enabled = videoUri != null,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("СОБРАТЬ ВИДЕО") }
                }
                if (scenes.isNotEmpty()) {
                    item { Text("План сцен (${scenes.size})", style = MaterialTheme.typography.titleMedium) }
                    items(scenes) { scene ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Сцена ${scene.number}")
                                Text("${scene.start} → ${scene.end}")
                            }
                        }
                    }
                }
            }
        }
    }
}
